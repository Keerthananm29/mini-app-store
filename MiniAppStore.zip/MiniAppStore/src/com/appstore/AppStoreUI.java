package com.appstore;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class AppStoreUI extends JFrame {
    private AppStoreManager appStoreManager;
    private String selectedPhotoPath;

    public AppStoreUI(AppStoreManager appStoreManager) {
        this.appStoreManager = appStoreManager;
        setTitle("Mini App Store");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // App List Panel
        JPanel appListPanel = new JPanel();
        appListPanel.setLayout(new GridLayout(0, 1));
        JScrollPane scrollPane = new JScrollPane(appListPanel);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Add App Panel
        JPanel addAppPanel = new JPanel();
        addAppPanel.setLayout(new GridLayout(5, 2));

        JLabel nameLabel = new JLabel("App Name:");
        JTextField nameField = new JTextField();
        JLabel descriptionLabel = new JLabel("Description:");
        JTextField descriptionField = new JTextField();
        JLabel priceLabel = new JLabel("Price:");
        JTextField priceField = new JTextField();
        JLabel photoLabel = new JLabel("Photo:");
        JButton photoButton = new JButton("Select Photo");
        JButton addButton = new JButton("Add App");

        addAppPanel.add(nameLabel);
        addAppPanel.add(nameField);
        addAppPanel.add(descriptionLabel);
        addAppPanel.add(descriptionField);
        addAppPanel.add(priceLabel);
        addAppPanel.add(priceField);
        addAppPanel.add(photoLabel);
        addAppPanel.add(photoButton);
        addAppPanel.add(new JLabel()); // Empty cell
        addAppPanel.add(addButton);

        panel.add(addAppPanel, BorderLayout.NORTH);

        // Photo Button Event Handling
        photoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                int result = fileChooser.showOpenDialog(AppStoreUI.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    selectedPhotoPath = selectedFile.getAbsolutePath();
                }
            }
        });

        // Add Button Event Handling
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String description = descriptionField.getText();
                double price;
                try {
                    price = Double.parseDouble(priceField.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(AppStoreUI.this, "Invalid price.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (selectedPhotoPath == null) {
                    JOptionPane.showMessageDialog(AppStoreUI.this, "Please select a photo.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                App newApp = new App(name, description, price, selectedPhotoPath);
                appStoreManager.addApp(newApp);
                refreshAppList(appListPanel);
                nameField.setText("");
                descriptionField.setText("");
                priceField.setText("");
                selectedPhotoPath = null;
            }
        });

        getContentPane().add(panel);
    }

    private void refreshAppList(JPanel appListPanel) {
        appListPanel.removeAll();
        for (App app : appStoreManager.getApps()) {
            JPanel appPanel = new JPanel();
            appPanel.setLayout(new BorderLayout());

            JLabel appLabel = new JLabel(app.getName() + " - " + app.getDescription() + " - $" + app.getPrice());
            appPanel.add(appLabel, BorderLayout.NORTH);

            if (app.getPhotoPath() != null) {
                ImageIcon imageIcon = new ImageIcon(app.getPhotoPath());
                Image image = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                JLabel photoLabel = new JLabel(new ImageIcon(image));
                appPanel.add(photoLabel, BorderLayout.CENTER);
            }

            appListPanel.add(appPanel);
        }
        appListPanel.revalidate();
        appListPanel.repaint();
    }
}
