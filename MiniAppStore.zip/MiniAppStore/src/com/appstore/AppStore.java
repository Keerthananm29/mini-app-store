package com.appstore;

public class AppStore {
    public static void main(String[] args) {
        AppStoreManager appStoreManager = new AppStoreManager();
        AppStoreUI appStoreUI = new AppStoreUI(appStoreManager);
        appStoreUI.setVisible(true);
    }
}
