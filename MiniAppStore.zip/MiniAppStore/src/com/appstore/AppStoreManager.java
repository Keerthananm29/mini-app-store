package com.appstore;

import java.util.ArrayList;
import java.util.List;

public class AppStoreManager {
    private List<App> apps;

    public AppStoreManager() {
        apps = new ArrayList<>();
    }

    public void addApp(App app) {
        apps.add(app);
    }

    public List<App> getApps() {
        return apps;
    }
}
