package com.appstore;

public class App {
    private String name;
    private String description;
    private double price;
    private String photoPath;

    public App(String name, String description, double price, String photoPath) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.photoPath = photoPath;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public String getPhotoPath() {
        return photoPath;
    }
}
