package com.appstore;

import java.util.ArrayList;
import java.util.List;

public class AppStoreManager {
    private List<App> apps;

    public AppStoreManager() {
        apps = new ArrayList<>();
        loadDummyData();
    }

    public List<App> getApps() {
        return apps;
    }

    private void loadDummyData() {
         
        apps.add(new App("INSTAGRAM", "Share what you're into with the people who get you.",   "src/resources/insta.png", "http://instagram.com"));
        apps.add(new App("WHATSAPP", "End-to-end encrypted. Quickly send and receive WhatsApp messages right from your computer.",  "src/resources/WHAT.png", "https://www.bing.com/ck/a?!&&p=a54d57537444db74JmltdHM9MTcxOTI3MzYwMCZpZ3VpZD0wYjE2OTMwZS04YmVhLTYyYjUtMTYwZi04Nzg0OGExZDYzYWUmaW5zaWQ9NTIyMA&ptn=3&ver=2&hsh=3&fclid=0b16930e-8bea-62b5-160f-87848a1d63ae&psq=whatsapp+web&u=a1aHR0cHM6Ly93ZWIud2hhdHNhcHAuY29tLw&ntb=1"));
        apps.add(new App("SNAPCHAT", "Chat, send Snaps, explore Stories & Lenses on desktop, or download the app for mobile! Connect & create with friends, wherever you are ", "src/resources/SNAP.png", "https://accounts.snapchat.com/accounts/v2/login"));
        apps.add(new App("FACEBOOK", "Log into Facebook to start sharing and connecting with your friends, family, and people you know.",   "src/resources/FACE.png", "https://www.facebook.com/"));
        apps.add(new App("GOOGLE MAPS", " Find local businesses, view maps and get driving directions in Google Maps", "src/resources/MAP.png", "https://www.google.co.in/maps"));
        apps.add(new App("FLIPCART", "Flipkart is India's biggest online store for various products, from mobiles and electronics to home and furniture. Shop from all brands at the lowest prices and enjoy payment options",   "src/resources/FLIP.png", "https://www.flipkart.com/"));
        apps.add(new App("WEATHER", "DesThe weather app provides current and forecasted temperature, humidity, pressure and descriptions for cities searched by users. It enables better daily planning ",   "src/resources/WETH.png", "https://www.msn.com/en-in/weather/maps/severeweather/in-Mandya,Ka?ocid=ansmsnweather&loc=eyJsIjoiTWFuZHlhIiwiciI6IkthIiwicjIiOiJNYW5keWEiLCJjIjoiSW5kaWEiLCJpIjoiSU4iLCJnIjoiZW4taW4iLCJ4IjoiNzYuODc3IiwieSI6IjEyLjUxOSJ9"));
        apps.add(new App("CALCULATOR", "Online Calculator offers a range of free, easy to use calculators, conversion tools, and more for various purposes. Whether you need a simple calculator, a scientific calculator",   "src/resources/cal.png", "https://www.calculator.net/"));
        apps.add(new App("ICLOUD", "iCloud is a service that lets you access your photos, mail, notes, documents and more from any device. However, it encountered an error while trying to connect to the server ",  "src/resources/ICLO.png", "https://www.icloud.com/"));
        apps.add(new App("TELEGRAM", "Log in to Telegram by QR Code. Open Telegram on your phone. Go to Settings → Devices → Link Desktop Device. Point your phone at this screen to confirm login",  "src/resources/TEL.png", "https://web.telegram.org/"));
        apps.add(new App("AMAZON", "Shop online for mobiles, books, watches, shoes and more at Amazon.in, India's largest online marketplace. Find deals, discounts, ",   "src/resources/AMAZ.png", "https://www.amazon.in/?tag=msndeskstdin-21&ref=pd_sl_8kl3gdv5k3_e&adgrpid=1315017564951826&hvadid=82188862025546&hvnetw=o&hvqmt=e&hvbmt=be&hvdev=c&hvlocint=&hvlocphy=143997&hvtargid=kwd-82189528134796:loc-90&hydadcr=14452_2334185&msclkid=7010e5c8eaed1356fccc83b37b0f60ca"));
        apps.add(new App("SPOTIFY", "Web Player: Music for everyone. Preview of Spotify. Sign up to get unlimited songs and podcasts with occasional ads. No credit card needed",   "src/resources/SPO.png", "https://open.spotify.com/"));
        apps.add(new App("CHROME", "Google Chrome is a fast, secure, and free web browser, built for the modern web. Give it a try on your desktop today.",  "src/resources/CHO.png", "https://www.google.com/intl/en/chrome/"));
        apps.add(new App("CAHTGPT", "ChatGPT is a model that interacts in a dialogue format and can answer followup questions, admit mistakes, and reject inappropriate requests. It is trained using reinforcement learning from human feedback",   "src/resources/GPT.png", "https://openai.com/index/chatgpt/"));
        apps.add(new App("GOOGLE DRIVE", "Access Google Drive with a Google account (for personal use) or Google Workspace account (for business use).",   "src/resources/DRI.png", "https://drive.google.com/drive/home"));
        apps.add(new App("NETFIX", "Watch Netflix movies & TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more.",  "src/resources/NET.png", "https://www.netflix.com/in/?com%27="));
        
    }
}
