package com.appstore;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.stream.Collectors;

public class AppStoreUI extends JFrame {
    private AppStoreManager appStoreManager;
    private JPanel appGridPanel;
    private JTextField searchField;

    public AppStoreUI(AppStoreManager appStoreManager) {
        this.appStoreManager = appStoreManager;
        setTitle("App Store");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBackground(new Color(0, 150, 136));
        headerPanel.setPreferredSize(new Dimension(0, 80));

        JLabel titleLabel = new JLabel("App Store");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        headerPanel.add(titleLabel, BorderLayout.CENTER);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        
        JPanel searchBarPanel = new JPanel();
        searchBarPanel.setLayout(new BorderLayout());
        searchBarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        searchField = new JTextField();
        searchField.setFont(new Font("Arial", Font.PLAIN, 18));
        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Arial", Font.BOLD, 18));
        searchButton.setBackground(new Color(33, 150, 243));
        searchButton.setForeground(Color.WHITE);

        searchBarPanel.add(searchField, BorderLayout.CENTER);
        searchBarPanel.add(searchButton, BorderLayout.EAST);

        mainPanel.add(searchBarPanel, BorderLayout.NORTH);

        
        appGridPanel = new JPanel();
        appGridPanel.setLayout(new GridLayout(0, 4, 10, 10)); // 4 columns grid with gaps
        appGridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JScrollPane scrollPane = new JScrollPane(appGridPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        
        refreshAppGrid(appStoreManager.getApps());

        
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performSearch();
            }
        });

        
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performSearch();
                }
            }
        });

        getContentPane().add(mainPanel);
    }

    private void performSearch() {
        String query = searchField.getText().toLowerCase();
        List<App> filteredApps = appStoreManager.getApps().stream()
                .filter(app -> app.getName().toLowerCase().contains(query) ||
                               app.getDescription().toLowerCase().contains(query))
                .collect(Collectors.toList());
        refreshAppGrid(filteredApps);
    }

    private void refreshAppGrid(List<App> apps) {
        appGridPanel.removeAll();
        for (App app : apps) {
            JPanel appPanel = new JPanel();
            appPanel.setLayout(new BorderLayout());
            appPanel.setBackground(Color.WHITE);
            appPanel.setPreferredSize(new Dimension(250, 300));
            appPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

            JPanel detailsPanel = new JPanel();
            detailsPanel.setLayout(new BorderLayout());

            JLabel appLabel = new JLabel("<html><b>" + app.getName() + "</b><br>" + app.getDescription() + "</html>");
            appLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            detailsPanel.add(appLabel, BorderLayout.NORTH);

            if (app.getPhotoPath() != null) {
                ImageIcon imageIcon = new ImageIcon(app.getPhotoPath());
                Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                JLabel photoLabel = new JLabel(new ImageIcon(image));
                photoLabel.setHorizontalAlignment(SwingConstants.CENTER);
                detailsPanel.add(photoLabel, BorderLayout.CENTER);
            }

            JButton launchButton = new JButton("Launch");
            launchButton.setFont(new Font("Arial", Font.BOLD, 14));
            launchButton.setBackground(new Color(76, 175, 80));
            launchButton.setForeground(Color.WHITE);
            launchButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new AppLaunchUI(app).setVisible(true);
                }
            });

            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(launchButton);
            detailsPanel.add(buttonPanel, BorderLayout.SOUTH);

            appPanel.add(detailsPanel, BorderLayout.CENTER);

            appGridPanel.add(appPanel);
        }
        appGridPanel.revalidate();
        appGridPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AppStoreManager manager = new AppStoreManager();
            new AppStoreUI(manager).setVisible(true);
        });
    }
}
