package com.appstore;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;

public class AppLaunchUI extends JFrame {
    private App app;

    public AppLaunchUI(App app) {
        this.app = app;
        setTitle("Launch " + app.getName());
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JLabel appLabel = new JLabel(  app.getName());
        appLabel.setFont(new Font("Arial", Font.BOLD, 24));
        appLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(appLabel, BorderLayout.NORTH);

        if (app.getPhotoPath() != null) {
            ImageIcon imageIcon = new ImageIcon(app.getPhotoPath());
            Image image = imageIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
            JLabel photoLabel = new JLabel(new ImageIcon(image));
            photoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            mainPanel.add(photoLabel, BorderLayout.CENTER);
        }

        JButton openUrlButton = new JButton("Open " + app.getName());
        openUrlButton.setFont(new Font("Arial", Font.BOLD, 18));
        openUrlButton.setBackground(new Color(76, 175, 80));
        openUrlButton.setForeground(Color.WHITE);
        openUrlButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI(app.getUrl()));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(openUrlButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);
    }
}
