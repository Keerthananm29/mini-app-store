package com.appstore;
public class App {
    private String name;
    private String description;
    
    private String photoPath;  
    private String url;        

    public App(String name, String description, String photoPath, String url) {
        this.name = name;
        this.description = description;
        
        this.photoPath = photoPath;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public String getUrl() {
        return url;
    }
}
